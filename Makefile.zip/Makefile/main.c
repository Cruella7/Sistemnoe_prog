#include "hello.h"

int main(){
	hello_message("Sofia");
	return 0;
}

