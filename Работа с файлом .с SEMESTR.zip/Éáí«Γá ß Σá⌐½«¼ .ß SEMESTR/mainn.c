#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Функция для вычисления среднего арифметического оценок в строке
float calcAveg(const char *line) {
    int sum = 0;    // Сумма всех оценок в строке
    int count = 0;  // Количество оценок в строке

    // Перебор каждого символа в строке
    for (int i = 0; line[i] != '\0'; i++) {
        if (line[i] >= '0' && line[i] <= '9') {
            sum += line[i] - '0';
            count++;
        }
    }

    // Если в строке есть оценки, возвращаем среднее арифметическое, иначе возвращаем 0
    if (count > 0) {
        return (float)sum / count;
    } else {
        return 0;
    }
}

int main() {
    // Открытие файлов для чтения и записи
    FILE *in = fopen("l_semestr.txt", "r");
    FILE *out = fopen("output.txt", "w");

    // Проверка успешности открытия файлов
    if (in == NULL || out == NULL) {
        printf("Ошибка открытия файла\n");
        return 1;
    }

    char line[100]; // Буфер для хранения строки из файла
    // Пока есть строки в файле для чтения, выполняем следующий код
    while (fgets(line, sizeof(line), in) != NULL) {
        float avg = calcAveg(line);
        // Записываем исходную строку и полученное среднее значение в файл вывода
        fprintf(out, "%s;%.2f\n", line, avg);
    }
    fclose(in);
    fclose(out);

    printf("Операция завершена успешно.\n");

    return 0;
}