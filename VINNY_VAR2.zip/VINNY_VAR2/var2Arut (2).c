#include <stdio.h>
#include <string.h>

#define MAX_BUSES 100
#define MAX_LEN 50

// Структура для хранения информации о движении автобусов
typedef struct {
    char number[MAX_LEN];   // Номер автобуса
    char station[MAX_LEN];  // Название станции
    int passengers;         // Количество пассажиров
} BusInfo;

int main() {
    // Открытие файла для чтения
    FILE *in_file = fopen("in.txt", "r");
    if (in_file == NULL) {
        printf("Ошибка открытия файла in.txt\n");
        return 1;
    }

    // Создание массива структур BusInfo
    BusInfo buses[MAX_BUSES];
    int num_buses = 0;  // Количество автобусов

    // Чтение данных из файла и заполнение массива структур
    while (fscanf(in_file, "%s %s %d", buses[num_buses].number, buses[num_buses].station, &buses[num_buses].passengers) == 3) {
        num_buses++; // Увеличение счетчика автобусов
    }
    fclose(in_file); // Закрытие файла после чтения

    // Вычисление общего количества пассажиров для каждого автобуса
    for (int i = 0; i < num_buses; i++) {
        if (buses[i].passengers == 0) continue; // Пропускаем уже обработанные автобусы
        for (int j = i + 1; j < num_buses; j++) {
            if (strcmp(buses[i].number, buses[j].number) == 0) {
                buses[i].passengers += buses[j].passengers;
                buses[j].passengers = 0; // Помечаем, что автобус j уже обработан
            }
        }
    }

    // Открытие файла для записи результатов
    FILE *out_file = fopen("out.txt", "w");
    if (out_file == NULL) {
        printf("Ошибка открытия файла out.txt\n");
        return 1;
    }

    // Вывод информации о количестве пассажиров в каждом автобусе в файл
    fprintf(out_file, "Номер | Количество пассажиров\n");
    for (int i = 0; i < num_buses; i++) {
        if (buses[i].passengers != 0) { // Проверяем, что количество пассажиров не равно 0
            fprintf(out_file, "%s %d\n", buses[i].number, buses[i].passengers);
        }
    }
    fclose(out_file); // Закрытие файла после записи
    return 0;
}
