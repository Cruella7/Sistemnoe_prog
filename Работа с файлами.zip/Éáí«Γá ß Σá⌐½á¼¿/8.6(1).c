/*Форматированный вывод*/
#include <stdio.h>
 
// Определение структуры для представления информации о человеке
struct person
{
    char name[20];
    int age;
};

int main(void)
{
    // Имя файла для сохранения данных
    char * filename = "users.dat";
    // Массив структур, содержащий информацию о людях
    struct person people[] = { {"Tom", 23}, {"Alice", 27}, {"Bob", 31}, {"Kate", 29} };
    // Количество записываемых структур
    int n = sizeof(people)/sizeof(people[0]);
    // Открытие файла для записи
    FILE *fp = fopen(filename, "w");
    // Проверка на успешное открытие файла
    if (!fp)
    {
        printf("Error occured while opening file\n"); // Вывод сообщения об ошибке, если файл не открылся
        return 1; // Возвращаем ненулевое значение, чтобы указать на ошибку
    }
      
    // Запись информации о людях в файл
    for(int i=0; i < n; i++)
    {
        fprintf(fp, "%s  %d\n", people[i].name, people[i].age); // Запись имени и возраста в файл
    }
    fclose(fp); // Закрытие файла
    printf("File has been written\n"); // Вывод сообщения об успешной записи файла
    return 0; // Успешное завершение программы
}
