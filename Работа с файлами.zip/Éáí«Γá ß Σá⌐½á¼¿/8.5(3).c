/*Копирование файлов*/
/*Копирование файлов*/
#include <stdio.h>
 
int main(void)
{
    // Имена файлов
    char * filename1 = "data1.txt";
    char * filename2 = "data2.txt";
    char buffer[256]; // Буфер для считывания строк из файла
 
    // Открытие файла для чтения (filename1)
    FILE *f1 = fopen(filename1, "r");   // файл на чтение
    // Открытие файла для записи (filename2)
    FILE *f2 = fopen(filename2, "w");   // файл на запись
 
    // Проверка на успешное открытие файлов
    if(!f1 || !f2)
    {
        printf("Error occured while opening file\n"); // Вывод сообщения об ошибке, если файлы не открылись
    }
    else
    {
        // пока не дойдем до конца, считываем по 256 байт из файла f1
        while((fgets(buffer, 256, f1))!=NULL)
        {
            // записываем строку в файл f2
            fputs(buffer, f2); // Запись строки в файл f2
            printf("%s", buffer); // Вывод считанной строки на экран
        }
    }
     
    fclose(f1); // Закрытие файла f1
    fclose(f2); // Закрытие файла f2
     
    return 0;
}