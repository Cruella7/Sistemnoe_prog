/*Запись-чтение массива структур*/
#include <stdio.h>
 
struct person // данные о человеке
{
    char name[20];
    int age;
};
 
int main() {
    // Указание имени файла
    char * filename = "people.bin";
     
    // массив для записи
    struct person people[] = { {"Tom", 23}, {"Alice", 27}, {"Bob", 31}, {"Kate", 29 }};
    int size = sizeof(people[0]);              // размер одной структуры
    int count = sizeof(people)  / size;         // количество структур в массиве
     
    // запись файла
    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        // Проверка на успешное открытие файла
        printf("Error opening file for writing.\n");
        return 1;  // Возвращаем ненулевое значение, чтобы указать на ошибку
    }
    // записываем массив структур в файл
    size_t written = fwrite(people, size, count, fp); 
    printf("wrote %zu elements out of %d\n", written, count);
    fclose(fp);
 
    // считывание файла
    struct person users[count];  // массив для чтения структур из файла
    fp = fopen(filename, "r");
    if (fp == NULL) {
        // Проверка на успешное открытие файла
        printf("Error opening file for reading.\n");
        return 1;  // Возвращаем ненулевое значение, чтобы указать на ошибку
    }
    size_t read = fread(users, size, count, fp); 
    printf("read %zu elements\n", read);
 
    if(read > 0)
    {  
        // Вывод информации о считанных структурах
        for(int i = 0; i < count; i++)
        {
            printf("Name: %s \t Age: %d\n", users[i].name, users[i].age);
        }
    }
    fclose(fp);
    return 0; // Успешное завершение программы
}
