/*Считывание по одной структуре*/
#include <stdio.h>
 
// Определение структуры для представления информации о человеке
struct person
{
    char name[20];
    int age;
};
 
// Прототипы функций
void save(char*);
void read_by_age(char*, int);
 
int main() {
    char * filename = "people.bin";
    // Сохраняем данные о людях в файл
    save(filename);
    // Читаем данные из файла и выводим информацию о людях определенного возраста
    read_by_age(filename, 22);   // находим пользователей, которым 22 года
}
 
// Функция для сохранения данных о людях в файл
void save(char* filename)
{
    // Массив структур, содержащий информацию о людях
    struct person people[] = { {"Tom", 22}, {"Bob", 33}, {"Kate", 33 }, {"Alice", 22}};
    int size = sizeof(people[0]);              // Размер одной структуры
    int count = sizeof(people)  / size;         // Количество структур в массиве
 
    // Открытие файла для записи
    FILE *fp = fopen(filename, "w");
    // Запись массива структур в файл
    size_t written = fwrite(people, size, count, fp); 
    printf("wrote %zu elements out of %d\n", written, count);
    fclose(fp);
}

// Функция для чтения данных из файла и вывода информации о людях определенного возраста
void read_by_age(char* filename, int age)
{
    struct person p;  // Временная переменная для хранения считанных данных о человеке
    FILE* fp = fopen(filename, "r"); // Открытие файла для чтения
    // Пока есть данные для чтения из файла
    while(fread(&p, sizeof(p), 1, fp) == 1)
    {
        // Если возраст считанного человека совпадает с заданным возрастом
        if(p.age == age)
        {
            // Выводим информацию о человеке на экран
            printf("Name: %s \t Age: %d \n", p.name, p.age);
        }
    }
    fclose(fp); // Закрытие файла
}